def encrypt():
    plainText = input("Enter a one-word, lowercase message: ")
    distance = int(input("Enter the distance value: "))
    code = ""
    for ch in plainText:
        ordvalue = ord(ch)
        cipherValue = ordvalue + distance
        if cipherValue > ord('z'):
            cipherValue = ord('a') + (cipherValue - ord('z') - 1)

        code += chr(cipherValue)

    print(code)

def decrypt():
    code = input("Enter the coded text: ")
    distance = int(input("Enter the distance value: "))
    plainText = ""
    for ch in code:
        ordvalue = ord(ch)
        cipherValue = ordvalue - distance
        if cipherValue < ord('a'):
            cipherValue = ord('z') - (ord('a') - cipherValue - 1)

        plainText += chr(cipherValue)

    print(plainText)

def main():
    while True:
        print("\nChoose an option:")
        print("1. Encrypt a message")
        print("2. Decrypt a message")
        print("3. Exit")
        
        choice = input("Enter your choice (1/2/3): ")

        if choice == '1':
            encrypt()
        elif choice == '2':
            decrypt()
        elif choice == '3':
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")

if __name__ == "__main__":
    main()