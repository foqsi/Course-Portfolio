def calculate_total_distance(initial_height, bounciness_index, number_of_bounces):
    total_distance = 0
    height = initial_height

    for _ in range(number_of_bounces):
        total_distance += height

        height = height * bounciness_index

        total_distance += height

    return total_distance


initial_height = float(input("Enter the initial height from which the ball is dropped (in feet): "))
bounciness_index = float(input("Enter the bounciness index of the ball (e.g., 0.6): "))
number_of_bounces = int(input("Enter the number of times the ball is allowed to bounce: "))

total_distance = calculate_total_distance(initial_height, bounciness_index, number_of_bounces)

print(f"The total distance traveled by the ball after {number_of_bounces} bounces is {total_distance:.2f} feet.")