def predict_population(initial_population, growth_rate, growth_period_hours, total_hours):
    growth_cycles = total_hours // growth_period_hours
    
    final_population = initial_population * (growth_rate ** growth_cycles)
    
    return final_population

initial_population = int(input("Enter the initial number of organisms: "))
growth_rate = float(input("Enter the rate of growth (e.g., 2 for doubling): "))
growth_period_hours = float(input("Enter the number of hours to achieve this growth rate: "))
total_hours = float(input("Enter the total number of hours during which the population grows: "))

final_population = predict_population(initial_population, growth_rate, growth_period_hours, total_hours)

print(f"The predicted population after {total_hours} hours is {int(final_population)} organisms.")
