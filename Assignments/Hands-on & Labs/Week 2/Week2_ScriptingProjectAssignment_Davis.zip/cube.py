length = float(input("Enter the length of an edge: "))

a = 6 * (length ** 2)

print(str(a))