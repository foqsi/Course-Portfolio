mass = float(input("Enter the object's mass(kg): "))
velocity = float(input("Enter the object's velocity(meters per second): "))

print("Object's momentum: " + str(mass * velocity))