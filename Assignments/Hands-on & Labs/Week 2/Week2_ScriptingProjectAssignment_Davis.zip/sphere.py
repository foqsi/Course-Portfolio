radius = float(input("Enter the radius of sphere: "))

p = 3.1415926535898
volume = 4/3 * p * radius ** 3
area = 4 * p * radius ** 2
circum = 2 * p * radius
diameter = 2 * radius

print("Volume: " + str(volume))
print("Area: " + str(area))
print("Circumference: " + str(circum))
print("Diameter: " + str(diameter))