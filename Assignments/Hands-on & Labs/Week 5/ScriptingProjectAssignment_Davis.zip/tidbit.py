def calculate_payment(price):
    down_payment = price * 0.10
    monthly_payment = price * 0.05
    return down_payment, monthly_payment

def generate_schedule(price):
    down_payment, monthly_payment = calculate_payment(price)
    balance = price - down_payment
    month = 0
    annual_rate = 0.12

    print(f"{'Month':<10}{'Balance':<15}{'Interest':<15}{'Principal':<15}{'Payment':<15}{'Remaining':<15}")
    print("-" * 85)

    while balance > 0:
        month += 1
        interest = balance * (annual_rate / 12)
        principal = monthly_payment - interest
        
        if principal > balance:
            monthly_payment = balance + interest
            principal = balance

        remaining = balance - principal

        print(f"{month:<10}${balance:<14.2f}${interest:<14.2f}${principal:<14.2f}${monthly_payment:<14.2f}${remaining:<14.2f}")

        balance = remaining
        if balance < 0.01:
            break

price = float(input("Enter the purchase price: $"))
print("\n")
generate_schedule(price)