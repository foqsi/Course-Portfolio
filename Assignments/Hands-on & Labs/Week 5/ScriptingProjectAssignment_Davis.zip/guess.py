import random

smaller = int(input("Enter the smaller number: "))
larger = int(input("Enter the larger number: "))

low = smaller
high = larger
count = 0

while True:
    count += 1
    guess = (low + high) // 2
    print(f"Computer's guess #{count}: {guess}")
    
    feedback = input("Is your number (h)igher, (l)ower, or (c)orrect? ").lower()
    
    if feedback == 'h':
        low = guess + 1
    elif feedback == 'l':
        high = guess - 1
    elif feedback == 'c':
        print(f"Congratulations to the computer! It guessed your number in {count} tries.")
        break
    else:
        print("Invalid input. Please enter 'h' for higher, 'l' for lower, or 'c' for correct.")
