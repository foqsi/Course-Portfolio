def generate_salary_schedule(starting_salary, percentage_increase, years):
    schedule = []
    current_salary = starting_salary
    
    for year in range(1, years + 1):
        schedule.append((year, round(current_salary, 2)))
        if year < 10:
            current_salary *= (1 + percentage_increase / 100)
    
    return schedule

def display_schedule(schedule):
    print(f"{'Year':<10}{'Salary':<15}")
    print("-" * 25)
    for year, salary in schedule:
        print(f"{year:<10}${salary:,.2f}")

def main():
    starting_salary = float(input("Enter the starting salary: $"))
    percentage_increase = float(input("Enter the percentage increase (e.g., 2 for 2%): "))
    years = int(input("Enter the number of years for the schedule: "))
    
    schedule = generate_salary_schedule(starting_salary, percentage_increase, years)
    display_schedule(schedule)

if __name__ == "__main__":
    main()