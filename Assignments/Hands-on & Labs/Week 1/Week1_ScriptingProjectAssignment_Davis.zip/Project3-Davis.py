base = float(input("Enter the base: "))
height = float(input("Enter the height: "))
area = .5 * base * height
print("The are of the triangle is" , area)
