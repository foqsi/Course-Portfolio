height = float(input("Enter the height: "))
width = float(input("Enter the width: "))
depth = float(input("Enter the depth: "))
volume = height * width * depth
print("The volume of the cuboid is", volume)
