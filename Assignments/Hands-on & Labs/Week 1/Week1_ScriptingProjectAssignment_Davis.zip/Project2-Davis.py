length = float(input("Enter the length: "))
width = float(input("Enter the width: "))
area = width * length
print("The area is", area, "square units.")