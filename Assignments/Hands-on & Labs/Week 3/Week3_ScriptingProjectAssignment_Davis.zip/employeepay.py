def calculate_weekly_pay(hourly_wage, regular_hours, overtime_hours):
    regular_pay = hourly_wage * regular_hours
    overtime_pay = overtime_hours * hourly_wage * 1.5
    total_pay = regular_pay + overtime_pay
    return total_pay

hourly_wage = float(input("Enter hourly wage (dollars): "))
regular_hours = float(input("Enter total regular hours worked: "))
overtime_hours = float(input("Enter total overtime hours worked: "))

total_pay = calculate_weekly_pay(hourly_wage, regular_hours, overtime_hours)

print(f"The total weekly pay is: ${total_pay:.2f}")