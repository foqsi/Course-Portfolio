def years_to_minutes(years):
    minutes_per_year = 365 * 24 * 60
    return years * minutes_per_year

years = float(input("Enter the number of years: "))

minutes = years_to_minutes(years)

print(f"{years} years is about {minutes} minutes.")